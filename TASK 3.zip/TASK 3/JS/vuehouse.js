function tengoDatos(datos) {


    var app = new Vue({
        el: '#apphou',
        data: {
            congresistas: datos,

        }
    });
}

var estadisticas = {
    hourep: 0,
    houdem: 0,
    houind: 0,
    pcthoudem: 0,
    pcthourep: 0,
    pcthouind: 0,
    total: 0,
    pcttotal: 0,
    menoscomprometidos: [],
    mascomprometidos: [],
    menoscomprometidosloyal: [],
    mascomprometidosloyal: [],

}

function cargarEstadistica(congresistas, estadisticas) {

    estadisticas.hourep = contador(congresistas, "R");
    estadisticas.houdem = contador(congresistas, "D");
    estadisticas.houind = contador(congresistas, "I");
    estadisticas.pcthoudem = (suma(congresistas, "D") / contador(congresistas, "D")).toFixed(2);
    estadisticas.pcthourep = (suma(congresistas, "R") / contador(congresistas, "R")).toFixed(2);
    estadisticas.pcthouind = (suma(congresistas, "I") / 2).toFixed(2);
    estadisticas.total = congresistas.length;
    estadisticas.pcttotal = (sum(congresistas) / congresistas.length).toFixed(2);
    estadisticas.menoscomprometidos = (sortJSON(congresistas, "missed_votes_pct", "desc")).slice(0,0.10*congresistas.length);
    estadisticas.mascomprometidos = (sortJSON(congresistas, "missed_votes_pct", "asc")).slice(0,0.10*congresistas.length);
    estadisticas.menoscomprometidosloyal = (sortJSON(congresistas, "missed_votes_pct", "asc")).slice(0,0.10*congresistas.length);
    estadisticas.mascomprometidosloyal = (sortJSON(congresistas, "missed_votes_pct", "desc")).slice(0,0.10*congresistas.length);
    
    return estadisticas;
}
