function tengoDatos(datos) {
    estadisticas = cargarEstadistica(datos, estadisticas);
    console.log(estadisticas)
    var app = new Vue({
        el: '#app',
        data: {
            senadores: datos,
            stadisticas: estadisticas,
            menos: estadisticas.menoscomprometidos,
            mas: estadisticas.mascomprometidos,
            menosloyal: estadisticas.menoscomprometidosloyal,
            masloyal: estadisticas.mascomprometidosloyal
        }
    });
}