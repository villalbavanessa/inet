function tengoDatos(datos) {


    var app = new Vue({
        el: '#app',
        data: {
            senadores: datos,

        }
    });
}


var estadisticas = {
    nrorep: 0,
    nrodem: 0,
    nroind: 0,
    pctdem: 0,
    pctrep: 0,
    pctind: 0,
    pcttotal: 0,
    menoscomprometidos: [],
    mascomprometidos: [],
    menoscomprometidosloyal: [],
    mascomprometidosloyal: [],

}

function cargarEstadistica(senadores, estadisticas) {
    
    estadisticas.nrodem = contador(senadores, "D");
    estadisticas.nrorep = contador(senadores, "R");
    estadisticas.nroind = contador(senadores, "I");
    estadisticas.pctdem = (suma(senadores, "D") / contador(senadores, "D")).toFixed(2);
    estadisticas.pctind = (suma(senadores, "I") / contador(senadores, "I")).toFixed(2);
    estadisticas.pctrep = (suma(senadores, "R") / contador(senadores, "R")).toFixed(2);
    estadisticas.total = senadores.length;
    estadisticas.pcttotal = (sum(senadores) / senadores.length).toFixed(2);
    estadisticas.menoscomprometidos = (sortJSON(senadores, "missed_votes_pct", "desc")).slice(0,0.10*senadores.length);
    estadisticas.mascomprometidos = (sortJSON(senadores, "missed_votes_pct", "asc")).slice(0,0.10*senadores.length);
    estadisticas.menoscomprometidosloyal = (sortJSON(senadores, "votes_with_party_pct", "desc")).slice(0,0.10*senadores.length);
    estadisticas.mascomprometidosloyal = (sortJSON(senadores, "votes_with_party_pct", "asc")).slice(0,0.10*senadores.length);
    
    return estadisticas;
}
