function contador(miembros, p) {
    var parti = 0;
    for (var i = 0; i < miembros.length; i++) {
        if (miembros[i].party == p) {
            parti++;
        }
    }
    return parti;
}

function getParty(array, party) {
    array.filter(miembro => {
        if (miembro.party == party) {
            return miembro;
        }
    });
    return array;
}

function suma(miembros, p) {
    var sum = 0;
    for (var i = 0; i < miembros.length; i++) {
        if (miembros[i].party == p) {
            sum = sum + miembros[i].votes_with_party_pct;
        }
    }
    return sum;
}

function sum(miembros) {
    var sum = 0;
    for (var i = 0; i < miembros.length; i++) {
        sum = sum + miembros[i].votes_with_party_pct;
    }
    return sum;
}

function sortJSON(array, key, orden) {
    console.log(array);
    return array.sort(function(a, b) {
        var x = a[key],
            y = b[key];
        if (orden === "asc") {
            return x < y ? -1 : x > y ? 1 : 0;
        }
        if (orden === "desc") {
            return x > y ? -1 : x < y ? 1 : 0;
        }
    });
}

