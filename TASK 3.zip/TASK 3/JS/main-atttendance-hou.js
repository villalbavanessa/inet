function tengoDatos(datos) {
    estadisticas = cargarEstadistica(datos, estadisticas)
    var apphou = new Vue({
        el: '#apphou',
        data: {
            congresistas: datos,
            stadisticas: estadisticas,
            menos: estadisticas.menoscomprometidos,
            mas: estadisticas.mascomprometidos,
            menosloyal: estadisticas.menoscomprometidosloyal,
            masloyal: estadisticas.mascomprometidosloyal
        }
    });
}