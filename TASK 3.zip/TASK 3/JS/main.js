var senadores = data.results[0].members;
console.log(senadores);
var fullname;
var pasarahtml = senadores.map(function(senadores) {
    if (senadores.middle_name == null) {
        fullname = senadores.last_name + " " + senadores.first_name;
    } else {
        fullname = senadores.last_name + " " + senadores.first_name + " " + senadores.middle_name;
    }
    return "<tr><td><a href=" + senadores.url + "> " + fullname + "</a></td><td>" + senadores.party + "</td><td>" + senadores.state + "</td><td>" + senadores.votes_with_party_pct + "&#37</td></tr>";
})
var tablasenadores = document.getElementById("senate-data");
tablasenadores.innerHTML = pasarahtml.join("");

var congresistas = data1.results[0].members;
console.log(congresistas);
var fullname;
var pasarahtml = congresistas.map(function(congresistas) {
    if (congresistas.middle_name == null) {
        fullname = congresistas.last_name + " " + congresistas.first_name;
    } else {
        fullname = congresistas.last_name + " " + congresistas.first_name + " " + congresistas.middle_name;
    }
    return "<tr><td><a href=" + congresistas.url + "> " + fullname + "</a></td><td>" + congresistas.party + "</td><td>" + congresistas.state + "</td><td>" + congresistas.seniority + "</td><td>" + congresistas.votes_with_party_pct + "&#37</td></tr>";
})
console.log(pasarahtml);
var tablacongresistas = document.getElementById("congress-data");
tablacongresistas.innerHTML = pasarahtml.join("");